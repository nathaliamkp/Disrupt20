package br.com.bttf.oracle;

import java.util.List;

import br.com.bttf.bean.Imagem;
import br.com.bttf.dao.ImagemDao;

public class ImagemOracleDao implements ImagemDao{

	@Override
	public Imagem pesquisar(int codigo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Imagem> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
