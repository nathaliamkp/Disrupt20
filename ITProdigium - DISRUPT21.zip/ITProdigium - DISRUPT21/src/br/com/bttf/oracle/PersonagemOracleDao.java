package br.com.bttf.oracle;

import java.util.List;

import br.com.bttf.bean.Cena;
import br.com.bttf.bean.Personagem;
import br.com.bttf.dao.PersonagemDao;

public class PersonagemOracleDao implements PersonagemDao{

	@Override
	public Personagem pesquisar(int codigo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Personagem> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Personagem> listarPorCena(Cena cena) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
