package br.com.bttf.oracle;

import java.util.List;

import br.com.bttf.bean.Cena;
import br.com.bttf.bean.Tecnologia;
import br.com.bttf.dao.TecnologiaDao;

public class TecnologiaOracleDao implements TecnologiaDao{

	@Override
	public Tecnologia pesquisar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Tecnologia> listar(int codigo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Tecnologia> listarPorCena(Cena cena) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
