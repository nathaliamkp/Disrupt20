package br.com.bttf.oracle;

import java.util.List;

import br.com.bttf.bean.Cena;
import br.com.bttf.dao.CenaDao;

public class CenaOracleDao implements CenaDao{

	@Override
	public Cena pesquisar(int codigo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cena> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
