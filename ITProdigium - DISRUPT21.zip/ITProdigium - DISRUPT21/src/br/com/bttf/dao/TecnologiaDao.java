package br.com.bttf.dao;

import java.util.List;

import br.com.bttf.bean.Cena;
import br.com.bttf.bean.Tecnologia;

public interface TecnologiaDao {

	Tecnologia pesquisar();
	
	List<Tecnologia> listar(int codigo);
	
	List<Tecnologia> listarPorCena(Cena cena);
}
