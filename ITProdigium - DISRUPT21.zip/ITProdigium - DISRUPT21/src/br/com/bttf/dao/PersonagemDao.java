package br.com.bttf.dao;

import java.util.List;

import br.com.bttf.bean.Cena;
import br.com.bttf.bean.Personagem;

public interface PersonagemDao {

	Personagem pesquisar(int codigo);
	
	List<Personagem> listar();
	
	List<Personagem> listarPorCena(Cena cena);
}
