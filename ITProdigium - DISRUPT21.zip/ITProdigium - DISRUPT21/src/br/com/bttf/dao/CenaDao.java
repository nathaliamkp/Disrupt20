package br.com.bttf.dao;

import java.util.List;

import br.com.bttf.bean.Cena;

public interface CenaDao {

	Cena pesquisar(int codigo);
	
	List<Cena> listar();
}
