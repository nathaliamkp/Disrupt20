package br.com.bttf.dao;

import java.util.List;

import br.com.bttf.bean.Imagem;

public interface ImagemDao {

	Imagem pesquisar(int codigo);
	
	List<Imagem> listar();
}
