package br.com.bttf.bean;

public class Personagem {

	private int id;
	
	private String nome;
	
	private String nomeAtor;
	
	private String relacao;
	
	private String desc;

	public Personagem() {}
	
	public Personagem(int id, String nome, String nomeAtor, String relacao, String desc) {
		super();
		this.id = id;
		this.nome = nome;
		this.nomeAtor = nomeAtor;
		this.relacao = relacao;
		this.desc = desc;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNomeAtor() {
		return nomeAtor;
	}

	public void setNomeAtor(String nomeAtor) {
		this.nomeAtor = nomeAtor;
	}

	public String getRelacao() {
		return relacao;
	}

	public void setRelacao(String relacao) {
		this.relacao = relacao;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	@Override
	public String toString() {
		return id + ", " + nome + ", " + nomeAtor + ", " + relacao + ", "
				+ desc;
	}
	
}
