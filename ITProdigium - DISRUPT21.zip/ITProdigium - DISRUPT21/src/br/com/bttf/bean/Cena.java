package br.com.bttf.bean;

import java.util.List;

public class Cena {

	private int id;
	
	private String nome;
	
	private Imagem img;
	
	private String desc;
	
	private List<Personagem> personagens;
	
	private List<Tecnologia> tecnologias;

	public Cena() {
		super();
	}

	public Cena(int id, String nome, Imagem img, String desc, List<Personagem> personagens,
			List<Tecnologia> tecnologias) {
		super();
		this.id = id;
		this.nome = nome;
		this.img = img;
		this.desc = desc;
		this.personagens = personagens;
		this.tecnologias = tecnologias;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Imagem getImg() {
		return img;
	}

	public void setImg(Imagem img) {
		this.img = img;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public List<Personagem> getPersonagens() {
		return personagens;
	}

	public void setPersonagens(List<Personagem> personagens) {
		this.personagens = personagens;
	}

	public List<Tecnologia> getTecnologias() {
		return tecnologias;
	}

	public void setTecnologias(List<Tecnologia> tecnologias) {
		this.tecnologias = tecnologias;
	}

	@Override
	public String toString() {
		return id + ", " + nome + ", " + img + ", " + desc + ", " + personagens
				+ ", " + tecnologias;
	}
	
}
